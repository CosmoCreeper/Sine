// => engine/services/updates.js
// ===========================================================
// This module allows Sine to update itself, removing the
// need for the user to reinstall Sine.
// ===========================================================

import utils from "chrome://userscripts/content/engine/utils/utils.js";
import ucAPI from "chrome://userscripts/content/engine/utils/uc_api.js";

export default {
    updaterName: "updater." + (ucAPI.os === "win" ? "bat" : "sh"),
    get downloadsFolder() {
        return PathUtils.join(FileUtils.getDir("Home", [], false).path, "Downloads");
    },
    get exePath() {
        return PathUtils.join(this.downloadsFolder, this.updaterName);
    },

    async updateEngine(update, releaseLink) {
        Services.appinfo.invalidateCachesOnRestart();

        try {
            // Convert mods to v2.3+ structure, to prevent necessary re-installing (despite recommended option).
            const mods = await utils.getMods();
            for (const mod of Object.values(mods)) {
                if (mod.preferences) {
                    mod.preferences = "preferences.json";
                } else {
                    mod.preferences = "";
                }

                if (mod.style) {
                    if (typeof mod.style === "object") {
                        if (mod.style.chrome) {
                            mod.style.chrome = "userChrome.css";
                        }
                        if (mod.style.content) {
                            mod.style.content = "userContent.css";
                        }
                    } else {
                        mod.style = "chrome.css";
                    }
                }
            }

            const dirSvc = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties);
            let browserPath = dirSvc.get("XREExeF", Ci.nsIFile).parent.path;
            
            // Fix snap install location
            if (browserPath.startsWith("/snap/firefox/")) {
                browserPath = "/etc/firefox";
            }

            // Create identifier to determine when update is complete.
            const identifierPath = PathUtils.join(ucAPI.sysChromeDir, "update");
            await IOUtils.writeUTF8(identifierPath, "");

            // Download updater.
            const updateLink = releaseLink.replace("{version}", "2.3") + this.updaterName;
            const resp = await ucAPI.fetch(updateLink, true);
            const buf = await resp.arrayBuffer();
            const bytes = new Uint8Array(buf);
            await IOUtils.write(this.exePath, bytes);

            // Set file as an executable on Unix-like systems.
            if (ucAPI.os !== "win") {
                const exe = FileUtils.File(this.exePath);
                exe.permissions = 0o755;
            }

            const file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
            file.initWithPath(this.exePath);

            const proc = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
            proc.init(file);

            const args = [
                "-s",
                "--browser", browserPath,
                "--profile", PathUtils.profileDir,
                "--bootloader", "0.1.2",
                "--version", "2.3",
            ];
            if (!update.updateBoot) {
                args.push("--no-boot");
            }

            proc.run(false, args, args.length);

            // Wait until updater is complete using identifier.
            await new Promise((resolve) => {
                const interval = setInterval(async () => {
                    if (!(await IOUtils.exists(identifierPath))) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 500);
            });

            await IOUtils.remove(this.exePath);
        } catch (err) {
            console.error("Error updating Sine: " + err);
            throw err;
        }

        Services.prefs.setStringPref("sine.version", update.version);
        Services.prefs.setBoolPref("sine.engine.pending-restart", true);

        ucAPI.restart(true);

        return true;
    },

    async fetch() {
        return await ucAPI
            .fetch(
                "https://raw.githubusercontent.com/CosmoCreeper/Sine/" +
                    (Services.prefs.getBoolPref("sine.is-cosine", false) ? "cosine" : "main") +
                    "/engine.json"
            )
            .catch((err) => console.warn(err));
    },

    async checkForUpdates() {
        const engine = await this.fetch();
        if (engine && engine.updates && engine.updates.length > 0 && engine.releaseLink) {
            Services.prefs.setStringPref("sine.latest-version", engine.updates[0].version);
            return await this.updateEngine(engine.updates[0], engine.releaseLink);
        }
    },
};
