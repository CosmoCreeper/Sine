const handleJS = async (newThemeData) => {
    const editableFiles = [];
    const promises = [];
    if (typeof newThemeData.js === "string" || typeof newThemeData.js === "array") {
        if (Services.prefs.getBoolPref("sine.allow-unsafe-js", false)) {
            const jsFiles = Array.isArray(newThemeData.js) ? newThemeData.js : [newThemeData.js];
            for (const file of jsFiles) {
                promises.push((async () => {
                    const fileContents = await ucAPI.fetch(file).catch(err => console.error(err));
                    if (typeof fileContents === "string" && fileContents.toLowerCase() !== "404: not found") {
                        const fileName = file.split("/").pop();
                        await IOUtils.writeUTF8(
                            PathUtils.join(utils.jsDir, newThemeData.id + "_" + fileName),
                            fileContents
                        );
                        editableFiles.push(`js/${fileName}`);
                    }
                })());
            }
        } else {
            ucAPI.showToast({
                title: "This mod uses unofficial JS.",
                description: "To install it, you must enable the option. (unsafe)",
                preset: 2,
                clickEvent: () => {
                    Services.prefs.setBoolPref("sine.allow-unsafe-js", true);
                    this.handleJS(newThemeData);
                }
            });
            return false;
        }
    } else {
        const dirLink = `https://api.github.com/repos/sineorg/store/contents/mods/${newThemeData.id}`;
        const newFiles = await ucAPI.fetch(dirLink).then(res => Object.values(res)).catch(err => console.warn(err));
        for (const file of newFiles) {
            promises.push((async () => {
                const fileContents = await ucAPI.fetch(file.download_url).catch(err => console.error(err));
                if (typeof fileContents === "string" && fileContents.toLowerCase() !== "404: not found") {
                    await IOUtils.writeUTF8(
                        PathUtils.join(utils.jsDir, newThemeData.id + "_" + file.name),
                        fileContents
                    );
                    editableFiles.push(`js/${file.name}`);
                }
            })());
        }
    }
    await Promise.all(promises);
    return this.convertPathsToNestedStructure(editableFiles);
}
